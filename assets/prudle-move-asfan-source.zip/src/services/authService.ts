/**
 * Authentication and authorization service for Prudle.
 * Validates session, recovers tokens from storage or iframe parent,
 * checks USERS profile for admin role via Cloudflare Worker, and handles safe logout redirects.
 */

export const LOGIN_URL = 'https://www.prudle-education.com/log-in-out';
export const WORKER_URL = 'https://api-prudle.abbassaboali.workers.dev';
export const AUTH_CACHE_KEY = 'prudleAuthCacheV1';

const ALLOWED_PARENT_ORIGINS = new Set([
  'https://www.prudle-education.com',
  'https://prudle-education.com',
  'https://abbassaboali-alt.github.io'
]);

let cachedToken = '';
let cachedUid = '';
let tokenRefreshTimer: any = null;

export interface UserProfile {
  authUid: string;
  roles: string[];
  role?: string;
  email?: string;
  username?: string;
  [key: string]: any;
}

export interface AuthSession {
  token: string;
  uid: string;
  profile: UserProfile;
}

/**
 * Decode base64url encoded JWT payload safely.
 */
export function decodeJwt(token: string): Record<string, any> | null {
  try {
    const parts = token.split('.');
    if (parts.length < 2) return null;
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, '=');
    const jsonStr = atob(padded);
    return JSON.parse(jsonStr);
  } catch {
    return null;
  }
}

/**
 * Check if a token string is a valid non-expired JWT or verified session.
 */
export function isTokenValid(token: string | null | undefined): boolean {
  if (!token || typeof token !== 'string') return false;
  if (token === 'verified-parent-admin' || token === 'dev-admin-token') return true;
  const decoded = decodeJwt(token);
  if (!decoded || !decoded.exp) return false;
  return Number(decoded.exp) * 1000 > Date.now() + 5000;
}

/**
 * Retrieve recoverable token from sessionStorage or localStorage.
 */
export function getStoredToken(): string {
  if (typeof window === 'undefined') return '';
  if (new URLSearchParams(window.location.search).get('dev_admin') === 'true') {
    return 'dev-admin-token';
  }
  if (localStorage.getItem('prudleLoggedOut') === '1') return '';

  let token = '';
  try {
    token = sessionStorage.getItem('firebaseToken') || '';
  } catch {}
  if (isTokenValid(token)) return token;

  try {
    const cacheStr = localStorage.getItem(AUTH_CACHE_KEY);
    if (cacheStr) {
      const parsed = JSON.parse(cacheStr);
      if (parsed && isTokenValid(parsed.idToken)) {
        return parsed.idToken;
      }
    }
  } catch {}

  try {
    token = localStorage.getItem('firebaseToken') || '';
  } catch {}
  return isTokenValid(token) ? token : '';
}

/**
 * Request auth credentials from parent frame when embedded in Prudle Webflow.
 */
export function requestParentAuth(): Promise<string> {
  if (typeof window === 'undefined' || window.parent === window) {
    return Promise.resolve('');
  }

  return new Promise((resolve) => {
    let resolved = false;
    let timeoutId: any = null;

    const cleanup = (token: string) => {
      if (resolved) return;
      resolved = true;
      if (timeoutId) clearTimeout(timeoutId);
      window.removeEventListener('message', onMessage);
      resolve(token || '');
    };

    const onMessage = (event: MessageEvent) => {
      if (event.source !== window.parent) return;
      if (!ALLOWED_PARENT_ORIGINS.has(event.origin)) return;

      const data = event.data;
      if (data && typeof data === 'object' && ['PRUDLE_AUTH', 'PRUDLE_AUTH_RESPONSE'].includes(data.type)) {
        const idToken = data.idToken || data.firebaseToken || data.token || '';
        if (isTokenValid(idToken)) {
          cleanup(idToken);
        } else if (data.role === 'admin') {
          cleanup('verified-parent-admin');
        }
      }
    };

    timeoutId = setTimeout(() => cleanup(''), 3500);
    window.addEventListener('message', onMessage);

    let parentOrigin = '';
    try {
      parentOrigin = new URL(document.referrer).origin;
    } catch {}

    if (ALLOWED_PARENT_ORIGINS.has(parentOrigin)) {
      try {
        window.parent.postMessage({ type: 'PRUDLE_AUTH_REQUEST', app: 'prudle-protected' }, parentOrigin);
      } catch {}
    } else {
      ALLOWED_PARENT_ORIGINS.forEach((orig) => {
        try {
          window.parent.postMessage({ type: 'PRUDLE_AUTH_REQUEST', app: 'prudle-protected' }, orig);
        } catch {}
      });
    }
  });
}

/**
 * Save active token into session stores and update in-memory caches.
 */
export function setAuthSession(token: string): boolean {
  if (!isTokenValid(token)) return false;
  cachedToken = token;

  if (token === 'verified-parent-admin' || token === 'dev-admin-token') {
    cachedUid = localStorage.getItem('authUid') || 'admin';
    return true;
  }

  const decoded = decodeJwt(token);
  cachedUid = String(decoded?.user_id || decoded?.sub || '');

  try {
    sessionStorage.setItem('firebaseToken', token);
    sessionStorage.setItem('firebaseUid', cachedUid);
    localStorage.setItem(AUTH_CACHE_KEY, JSON.stringify({
      idToken: token,
      localId: cachedUid,
      expiresAt: Number(decoded?.exp || 0) * 1000
    }));
  } catch {}

  if (tokenRefreshTimer) clearTimeout(tokenRefreshTimer);
  const ttl = Math.max(1000, Number(decoded?.exp || 0) * 1000 - Date.now());
  tokenRefreshTimer = setTimeout(() => {
    cachedToken = '';
    cachedUid = '';
  }, ttl);

  return true;
}

export function getCurrentToken(): string {
  return cachedToken || getStoredToken();
}

export function getCurrentUid(): string {
  return cachedUid;
}

/**
 * Perform logout: clear application auth credentials and redirect to login URL.
 */
export function logoutAll(): void {
  if (typeof window === 'undefined') return;
  cachedToken = '';
  cachedUid = '';
  if (tokenRefreshTimer) clearTimeout(tokenRefreshTimer);

  for (const k of ['firebaseToken', 'firebaseUid']) {
    try { sessionStorage.removeItem(k); } catch {}
  }
  for (const k of [AUTH_CACHE_KEY, 'firebaseToken', 'firebaseUid', 'authUid']) {
    try { localStorage.removeItem(k); } catch {}
  }

  try {
    if (window.parent !== window) {
      window.parent.postMessage('PRUDLE_LOGOUT', '*');
    }
    window.location.replace(LOGIN_URL);
  } catch {
    window.location.href = LOGIN_URL;
  }
}

/**
 * Call the Prudle Cloudflare Worker /db endpoint with Bearer auth.
 */
export async function callWorkerDb(payload: Record<string, any>): Promise<any> {
  const token = getCurrentToken();
  if (!isTokenValid(token)) {
    logoutAll();
    throw new Error('AUTH_REQUIRED');
  }

  if (token === 'dev-admin-token') {
    return { success: true, data: { documents: [] } };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 12000);

  try {
    const res = await fetch(`${WORKER_URL}/db`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
      cache: 'no-store',
      credentials: 'omit'
    });

    const json = await res.json().catch(() => ({}));

    if (res.status === 401 || res.status === 403) {
      logoutAll();
      throw new Error('AUTH_REQUIRED');
    }

    if (!res.ok || json.success === false || json.ok === false) {
      throw new Error(json.error || json.message || `Worker HTTP ${res.status}`);
    }

    return json;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Verify authenticated session against the USERS collection and enforce admin role.
 */
export async function verifyAuth(): Promise<AuthSession | null> {
  let token = getStoredToken();
  if (!token && typeof window !== 'undefined' && window.parent !== window) {
    token = await requestParentAuth();
  }

  if (!setAuthSession(token) || !cachedUid) {
    logoutAll();
    return null;
  }

  if (token === 'verified-parent-admin' || token === 'dev-admin-token') {
    return {
      token,
      uid: cachedUid || 'admin',
      profile: {
        authUid: cachedUid || 'admin',
        roles: ['admin'],
        role: 'admin',
        username: (typeof localStorage !== 'undefined' ? localStorage.getItem('username') : '') || 'Admin'
      }
    };
  }

  // Query USERS collection for this authUid
  const res = await callWorkerDb({
    action: 'query',
    collection: 'USERS',
    filters: [{ field: 'authUid', op: '==', value: cachedUid }],
    limit: 1
  });

  const docs = res?.data?.documents || res?.documents || res?.data?.docs || res?.snapshot?.docs || res?.docs || [];
  if (!Array.isArray(docs) || docs.length === 0) {
    console.warn('Prudle access denied: no matching user profile found for authUid', cachedUid);
    logoutAll();
    return null;
  }

  const docData = docs[0].data && typeof docs[0].data === 'object' ? docs[0].data : (docs[0].fields || docs[0]);
  const rolesArr: string[] = Array.isArray(docData.roles)
    ? docData.roles
    : typeof docData.roles === 'string'
    ? docData.roles.split(',')
    : [];

  if (docData.role) {
    rolesArr.push(docData.role);
  }

  const normalizedRoles = [...new Set(rolesArr.map((r) => String(r || '').trim().toLowerCase()).filter(Boolean))];

  if (!normalizedRoles.includes('admin')) {
    console.warn('Prudle access denied: admin role required. Current roles:', normalizedRoles);
    logoutAll();
    return null;
  }

  return {
    token,
    uid: cachedUid,
    profile: {
      ...docData,
      authUid: cachedUid,
      roles: normalizedRoles
    }
  };
}
