import React, { useState, useEffect } from 'react';
import { CourseRecord, Language, StudentRecord } from '../../types';
import { translations } from '../../i18n/translations';

interface MigrateModalProps {
  student: StudentRecord | null;
  targetCourse: CourseRecord | null;
  currentOverride?: number;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (
    student: StudentRecord,
    totalLevels: number,
    courseFee: number,
    paidAmount: number,
    remainingAmount: number
  ) => Promise<void>;
  lang: Language;
}

export const MigrateModal: React.FC<MigrateModalProps> = ({
  student,
  targetCourse,
  currentOverride,
  isOpen,
  onClose,
  onConfirm,
  lang
}) => {
  const t = translations[lang];
  const [totalLevels, setTotalLevels] = useState<number>(12);
  const [courseFee, setCourseFee] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [migrating, setMigrating] = useState<boolean>(false);

  useEffect(() => {
    if (student) {
      const lastLevels = student._lastLevels || { total: 0, used: 0, remaining: 0 };
      const defaultLevels = currentOverride || lastLevels.total || 12;
      setTotalLevels(defaultLevels);

      const fee = Number(student.CourseFee || 0) || Number(targetCourse?.CourseFee || 0);
      setCourseFee(fee);
      setPaidAmount(Number(student.PaidAmount || 0));
    }
  }, [student, targetCourse, currentOverride]);

  if (!isOpen || !student) return null;

  const remainingAmount = Math.max(courseFee - paidAmount, 0);

  const handleConfirm = async () => {
    const finalLevels = Math.max(1, Math.floor(Number(totalLevels) || 1));
    const finalFee = Number(courseFee) || 0;
    const finalPaid = Number(paidAmount) || 0;
    const finalRem = Math.max(finalFee - finalPaid, 0);

    setMigrating(true);
    try {
      await onConfirm(student, finalLevels, finalFee, finalPaid, finalRem);
      onClose();
    } catch (err) {
      console.error(err);
      alert(t.alertMigrateError);
    } finally {
      setMigrating(false);
    }
  };

  const studentName = student.name_en || student.name || '—';

  return (
    <div className="modal" style={{ display: 'flex' }}>
      <div className="modal-box">
        <h3>{t.modalMigrateTitle}</h3>
        <div className="sub">{studentName} — {student.iqama || '—'}</div>

        <label>{t.lblTotalLevels}</label>
        <input
          type="number"
          min="1"
          placeholder="e.g. 12"
          value={totalLevels}
          onChange={(e) => setTotalLevels(Math.max(1, Math.floor(Number(e.target.value) || 1)))}
        />

        <label>{t.lblCourseFee}</label>
        <input
          type="number"
          min="0"
          step="1"
          placeholder={t.courseFeeAutoPlaceholder}
          value={courseFee}
          onChange={(e) => setCourseFee(Number(e.target.value) || 0)}
        />

        <label>{t.lblPaidAmount}</label>
        <input
          type="number"
          min="0"
          step="1"
          placeholder="e.g. 0"
          value={paidAmount}
          onChange={(e) => setPaidAmount(Number(e.target.value) || 0)}
        />

        <label>{t.lblRemainingAmount}</label>
        <input
          type="number"
          min="0"
          step="1"
          value={remainingAmount}
          disabled
        />

        <div className="modal-actions">
          <button
            className="btn-gray"
            type="button"
            disabled={migrating}
            onClick={onClose}
          >
            {t.btnCancel}
          </button>
          <button
            className="btn-green"
            type="button"
            disabled={migrating}
            onClick={handleConfirm}
          >
            {migrating ? t.btnMigrating : t.btnConfirmMigrate}
          </button>
        </div>
      </div>
    </div>
  );
};
