import React, { useState, useEffect } from 'react';
import { Language, StudentRecord } from '../../types';
import { translations } from '../../i18n/translations';

interface SingleFeeModalProps {
  student: StudentRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (
    student: StudentRecord,
    courseFee: number,
    paidAmount: number,
    remainingAmount: number,
    paymentType: string
  ) => Promise<void>;
  lang: Language;
}

export const SingleFeeModal: React.FC<SingleFeeModalProps> = ({
  student,
  isOpen,
  onClose,
  onSave,
  lang
}) => {
  const t = translations[lang];
  const [courseFee, setCourseFee] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentType, setPaymentType] = useState<string>('');
  const [saving, setSaving] = useState<boolean>(false);

  useEffect(() => {
    if (student) {
      setCourseFee(Number(student.CourseFee || 0));
      setPaidAmount(Number(student.PaidAmount || 0));
      setPaymentType(student.PaymentType || '');
    }
  }, [student]);

  if (!isOpen || !student) return null;

  const remainingAmount = Math.max(courseFee - paidAmount, 0);

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(student, courseFee, paidAmount, remainingAmount, paymentType.trim());
      onClose();
    } catch (err) {
      console.error(err);
      alert(t.alertFeesError);
    } finally {
      setSaving(false);
    }
  };

  const studentName = student.name_en || student.name || '—';

  return (
    <div className="modal" style={{ display: 'flex' }}>
      <div className="modal-box">
        <h3>{t.modalFeesTitle}</h3>
        <div className="sub">{studentName} — {student.iqama || '—'}</div>

        <label>{t.lblCourseFee}</label>
        <input
          type="number"
          min="0"
          step="1"
          value={courseFee}
          onChange={(e) => setCourseFee(Number(e.target.value) || 0)}
        />

        <label>{t.lblPaidAmount}</label>
        <input
          type="number"
          min="0"
          step="1"
          value={paidAmount}
          onChange={(e) => setPaidAmount(Number(e.target.value) || 0)}
        />

        <label>{t.lblRemainingAmount}</label>
        <input
          type="number"
          min="0"
          step="1"
          value={remainingAmount}
          disabled
        />

        <label>{t.lblPaymentType}</label>
        <input
          type="text"
          placeholder={t.paymentTypePlaceholder}
          value={paymentType}
          onChange={(e) => setPaymentType(e.target.value)}
        />

        <div className="modal-actions">
          <button
            className="btn-blue"
            type="button"
            disabled={saving}
            onClick={handleSave}
          >
            {saving ? t.btnSaving : t.btnSave}
          </button>
          <button
            className="btn-gray"
            type="button"
            disabled={saving}
            onClick={onClose}
          >
            {t.btnClose}
          </button>
        </div>
      </div>
    </div>
  );
};
