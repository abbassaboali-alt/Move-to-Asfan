import React from 'react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, onToggleLang }) => {
  const t = translations[lang];

  return (
    <>
      <div className="header">
        <div className="header-top">
          <div style={{ width: '80px' }} />
          <div className="flex flex-col items-center">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJprpZXU4pTSCYXKhzWCpqdZ_mnPHMwqsACA&s"
              alt={t.logoAlt}
              className="header-logo"
            />
            <div className="mt-2 text-xl md:text-2xl font-black tracking-wide">
              {t.appTitle}
            </div>
          </div>
          <div className="flex items-center">
            <button
              type="button"
              onClick={onToggleLang}
              className="lang-switch-btn"
              title="Toggle English / العربية"
            >
              <i className="fa-solid fa-globe"></i>
              <span>{t.languageSwitch}</span>
            </button>
          </div>
        </div>
      </div>
      <div className="note">{t.branchSub}</div>
    </>
  );
};
