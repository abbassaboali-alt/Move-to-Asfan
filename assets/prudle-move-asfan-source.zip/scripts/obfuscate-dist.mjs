import fs from 'fs';
import path from 'path';
import JavaScriptObfuscator from 'javascript-obfuscator';

const distAssetsDir = path.resolve('dist/assets');

if (!fs.existsSync(distAssetsDir)) {
  console.error('Error: dist/assets directory not found for post-build obfuscation.');
  process.exit(1);
}

const files = fs.readdirSync(distAssetsDir);
const jsFiles = files.filter(f => f.endsWith('.js'));

if (jsFiles.length === 0) {
  console.warn('Warning: No JS files found in dist/assets to obfuscate.');
  process.exit(0);
}

console.log(`Starting post-build obfuscation on ${jsFiles.length} file(s)...`);

const obfuscationOptions = {
  compact: true,
  identifierNamesGenerator: 'hexadecimal',
  stringArray: true,
  stringArrayEncoding: ['base64'],
  stringArrayThreshold: 0.75,
  renameGlobals: false,
  renameProperties: false,
  selfDefending: false,
  debugProtection: false,
  controlFlowFlattening: false,
  deadCodeInjection: false,
  sourceMap: false
};

for (const jsFile of jsFiles) {
  const filePath = path.join(distAssetsDir, jsFile);
  const originalCode = fs.readFileSync(filePath, 'utf8');

  try {
    const obfuscationResult = JavaScriptObfuscator.obfuscate(originalCode, obfuscationOptions);
    fs.writeFileSync(filePath, obfuscationResult.getObfuscatedCode(), 'utf8');
    console.log(`✓ Obfuscated: ${jsFile}`);
  } catch (err) {
    console.error(`Failed to obfuscate ${jsFile}:`, err);
    process.exit(1);
  }
}

console.log('Post-build obfuscation completed successfully.');
